

S3_BUCKET_NAME = "creze-docs-api-dev-bucket"
COGNITO_APP_ID = "1n01pklns0cd17licmd7fh6rou"